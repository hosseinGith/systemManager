import "dotenv/config";
import express from "express";
import fs from "fs";
import mysql from "mysql2";
import { body } from "express-validator";
import rateLimit from "express-rate-limit";
import http from "http";
import { fileURLToPath } from "url";
import { dirname } from "path";

import moment from "moment-jalaali";
import bcrypt from "bcrypt";
import crypto from "crypto";
import jwt from "jsonwebtoken";
import nodemailer from "nodemailer";
import cookieParser from "cookie-parser";
import cookie from "cookie";
const __dirname = dirname(fileURLToPath(import.meta.url));

const globalPass = process.env.GLOBAL_PASS;
const globalKeys = [process.env.GLOBAL_KEY1, process.env.GLOBAL_KEY2];

const { dbhost, dbuser, dbdatabase, dbpassword } = process.env;

const hostDatabase = {
  host: dbhost,
  user: dbuser,
  database: dbdatabase,
  password: dbpassword,
};

const settings = (app) => {
  app.set("trust proxy", 1);
  app.use((req, res, next) => {
    res.setHeader(
      "Cache-Control",
      "no-store, no-cache, must-revalidate, private"
    );
    res.setHeader("Pragma", "no-cache");
    res.setHeader("Expires", "0");
    next();
  });
  // express
  app.use(express.static("public"));
  app.use(express.json());

  // cookie
  app.use(cookieParser());

  app.use(express.urlencoded({ extended: true }));

  const limiter = rateLimit({
    windowMs: 4 * 1000,
    max: 5,
    message: "لطفا چند ثانیه دیگر تلاش کنید.",
  });

  app.use(limiter);
};
let faDate = {
  days: {
    1: "یک",
    2: "دو",
    3: "سه",
    4: "چهار",
    5: "پنج",
    6: "شش",
    7: "هفت",
    8: "هشت",
    9: "نه",
    10: "ده",
    11: "یازده",
    12: "دوازده",
    13: "سیزده",
    14: "چهارده",
    15: "پانزده",
    16: "شانزده",
    17: "هفده",
    18: "هجده",
    19: "نوزده",
    20: "بیست",
    21: "بیست و یک",
    22: "بیست و دو",
    23: "بیست و سه",
    24: "بیست و چهار",
    25: "بیست و پنج",
    26: "بیست و شش",
    27: "بیست و هفت",
    28: "بیست و هشت",
    29: "بیست و نه",
    30: "سی",
    31: "سی و یک",
  },
};
export {
  mysql,
  bcrypt,
  jwt,
  nodemailer,
  body,
  rateLimit,
  moment,
  express,
  cookieParser,
  settings,
  crypto,
  fs,
  http,
  __dirname,
  globalPass,
  globalKeys,
  hostDatabase,
  faDate,
  cookie,
};
