const sectionTitle = document.querySelectorAll(".sectionTitle");
const menu = document.querySelector("#menu");
const showMenu = document.querySelector("#showMenu");
const booksArray = {
  اول: [
    "فارسی",
    "ریاضی",
    "علوم تجربی",
    "قرآن",
    "هدیه‌های آسمان",
    "کتاب نگارش فارسی",
    "آموزش قرآن",
  ],

  دوم: [
    "فارسی",
    "ریاضی",
    "علوم تجربی",
    "قرآن",
    "هدیه‌های آسمان",
    "کتاب نگارش فارسی",
    "آموزش قرآن",
  ],

  سوم: [
    "فارسی",
    "ریاضی",
    "علوم تجربی",
    "قرآن",
    "هدیه‌های آسمان",
    "کتاب نگارش فارسی",
    "آموزش قرآن",
  ],

  چهارم: [
    "فارسی",
    "ریاضی",
    "علوم تجربی",
    "مطالعات اجتماعی",
    "هدیه‌های آسمان",
    "قرآن",
    "نگارش فارسی",
    "آموزش قرآن",
  ],

  پنجم: [
    "فارسی",
    "ریاضی",
    "علوم تجربی",
    "مطالعات اجتماعی",
    "هدیه‌های آسمان",
    "قرآن",
    "نگارش فارسی",
    "آموزش قرآن",
  ],
  ششم: [
    "فارسی",
    "ریاضی",
    "علوم تجربی",
    "مطالعات اجتماعی",
    "هدیه‌های آسمان",
    "قرآن",
    "نگارش فارسی",
    "آموزش قرآن",
    "کار و فناوری",
    "تفکر و پژوهش",
  ],
  هفتم: [
    "فارسی",
    "نگارش",
    "عربی",
    "انگلیسی",
    "ریاضی",
    "علوم تجربی",
    "مطالعات اجتماعی",
    "هدیه‌های آسمان",
    "قرآن",
    "تفکر و سبک زندگی",
    "کار و فناوری",
    "فرهنگ و هنر",
  ],
  هشتم: [
    "فارسی",
    "نگارش",
    "عربی",
    "انگلیسی",
    "ریاضی",
    "علوم تجربی",
    "مطالعات اجتماعی",
    "هدیه‌های آسمان",
    "قرآن",
    "تفکر و سبک زندگی",
    "کار و فناوری",
    "فرهنگ و هنر",
  ],
  نهم: [
    "فارسی",
    "نگارش",
    "عربی",
    "انگلیسی",
    "ریاضی",
    "علوم تجربی",
    "مطالعات اجتماعی",
    "هدیه‌های آسمان",
    "قرآن",
    "کار و فناوری",
    "فرهنگ و هنر",
  ],
  دهم: {
    "ریاضی فیزیک": [
      "فارسی",
      "نگارش",
      "عربی",
      "زبان انگلیسی",
      "دین و زندگی",
      "ریاضی 1",
      "فیزیک 1",
      "شیمی 1",
      "هندسه 1",
      "علوم و فنون ادبی 1",
      "تفکر و سواد رسانه‌ای",
      "آمادگی دفاعی",
    ],
    تجربی: [
      "فارسی",
      "نگارش",
      "عربی",
      "زبان انگلیسی",
      "دین و زندگی",
      "ریاضی 1",
      "فیزیک 1",
      "شیمی 1",
      "زیست‌شناسی 1",
      "علوم و فنون ادبی 1",
      "تفکر و سواد رسانه‌ای",
      "آمادگی دفاعی",
    ],
    انسانی: [
      "فارسی",
      "نگارش",
      "عربی تخصصی",
      "زبان انگلیسی",
      "دین و زندگی",
      "منطق",
      "ریاضی و آمار 1",
      "اقتصاد",
      "تاریخ 1",
      "جغرافیا 1",
      "علوم و فنون ادبی 1",
      "آمادگی دفاعی",
    ],
  },
  یازدهم: {
    "ریاضی فیزیک": [
      "فارسی",
      "نگارش",
      "عربی",
      "زبان انگلیسی",
      "دین و زندگی",
      "ریاضی 2",
      "فیزیک 2",
      "شیمی 2",
      "هندسه 2",
      "آمار و احتمال",
      "علوم و فنون ادبی 2",
    ],
    تجربی: [
      "فارسی",
      "نگارش",
      "عربی",
      "زبان انگلیسی",
      "دین و زندگی",
      "ریاضی 2",
      "فیزیک 2",
      "شیمی 2",
      "زیست‌شناسی 2",
      "علوم و فنون ادبی 2",
    ],
    انسانی: [
      "فارسی",
      "نگارش",
      "عربی تخصصی",
      "زبان انگلیسی",
      "دین و زندگی",
      "ریاضی و آمار 2",
      "جامعه‌شناسی 1",
      "تاریخ 2",
      "جغرافیا 2",
      "فلسفه",
      "علوم و فنون ادبی 2",
    ],
  },
  دوازدهم: {
    "ریاضی فیزیک": [
      "فارسی",
      "نگارش",
      "عربی",
      "زبان انگلیسی",
      "دین و زندگی",
      "ریاضی 3",
      "فیزیک 3",
      "شیمی 3",
      "هندسه 3",
      "گسسته",
      "علوم و فنون ادبی 3",
    ],
    تجربی: [
      "فارسی",
      "نگارش",
      "عربی",
      "زبان انگلیسی",
      "دین و زندگی",
      "ریاضی 3",
      "فیزیک 3",
      "شیمی 3",
      "زیست‌شناسی 3",
      "علوم و فنون ادبی 3",
    ],
    انسانی: [
      "فارسی",
      "نگارش",
      "عربی تخصصی",
      "زبان انگلیسی",
      "دین و زندگی",
      "ریاضی و آمار 3",
      "جامعه‌شناسی 2",
      "تاریخ 3",
      "جغرافیا 3",
      "فلسفه 2",
      "علوم و فنون ادبی 3",
    ],
  },
};

async function deleteUser(id) {
  loading.classList.remove("opacity-0");
  loading.classList.remove("pointer-events-none");
  try {
    let res = await (
      await fetch("/delete", {
        method: "DELETE",
        headers: { "Content-type": "application/json" },
        body: JSON.stringify({
          id: id,
          nationalId: document.querySelector('[name="nationalId"]').value,
        }),
      })
    ).json();
    if (res.status) {
      Swal.fire({
        icon: "success",
        text: "کاربر حذف شد",
        confirmButtonText: "تایید",
        customClass: {
          confirmButton: "button",
        },
      }).then(() => {
        location = "/search";
      });
    } else
      Swal.fire({
        icon: "error",
        text: res.message,
        confirmButtonText: "تایید",
        customClass: {
          confirmButton: "button",
        },
      });
  } catch (e) {
    Swal.fire({
      icon: "error",
      text: "مشکل در سیستم.",
      confirmButtonText: "تایید",
      customClass: {
        confirmButton: "button",
      },
    });
    console.log(e);
  }
  loading.classList.add("opacity-0");
  loading.classList.add("pointer-events-none");
}
function showOther(element, condition) {
  if (condition) {
    element.type = "text";
  } else {
    element.type = "hidden";
  }
}

const isValidJalaliDate = (dateString) => {
  const regex = /^\d{4}\/\d{2}\/\d{2}$/;
  if (!regex.test(dateString)) return false;

  const date = moment(dateString, "jYYYY/jMM/jDD", true);
  if (!date.isValid()) return false;

  const [year, month, day] = dateString.split("/").map(Number);

  if (month < 1 || month > 12) return false;

  const daysInMonth = moment.jDaysInMonth(year, month);
  if (day < 1 || day > daysInMonth) return false;

  return true;
};

Array.from(sectionTitle).forEach((item) => {
  item.nextElementSibling
    .querySelectorAll(
      "input:not([type='hidden']),select:not([type='hidden']),textarea:not([type='hidden'])"
    )
    .forEach((input) => {
      input.addEventListener("focus", () => {
        if (item.parentElement.children[1].style.height) {
          item.parentElement.children[1].style.height = "";
          item.style.background = "#2f569d";
          item.style.color = "#fff";
          input.scrollIntoView({ behavior: true });
        }
      });
    });
  item.addEventListener("click", () => {
    if (item.parentElement.children[1].style.height) {
      item.parentElement.children[1].style.height = "";
      item.style.background = "#2f569d";
      item.style.color = "#fff";
    } else {
      item.parentElement.children[1].style.height = "calc-size(auto,0px)";
      item.style.background = "#000";
      item.style.color = "#fff";
    }
  });
});
if (showMenu) {
  showMenu.addEventListener("click", () => {
    if (menu.style.maxHeight == "0px") {
      menu.style = `max-height: 200px;width: 200px;`;
      menu.classList.remove("pointer-events-none");
      menu.classList.remove("opacity-0");
      menu.classList.remove("overflow-hidden");
      menu.classList.add("overflow-y-auto");
    } else {
      menu.style = `max-height: 0;width: 200px;`;
      menu.classList.add("pointer-events-none");
      menu.classList.add("overflow-hidden");
      menu.classList.add("opacity-0");
      menu.classList.remove("overflow-y-auto");
    }
  });
}
window.onclick = (e) => {
  if (showMenu && !e.target.closest("#showMenu")) {
    if (menu.style.maxHeight != "0px") {
      menu.style = `max-height: 0;width: 200px;`;
      menu.classList.add("pointer-events-none");
      menu.classList.add("overflow-hidden");
      menu.classList.add("opacity-0");
      menu.classList.remove("overflow-y-auto");
    }
  }
};

document.querySelectorAll(".window").forEach((item) => {
  item.onclick = function (e) {
    if (this === e.target) this.classList.remove("active");
  };
});
