import { fs } from "../core/settings.mjs";
import {
  checkUserAthu,
  errorHand,
  set_data_in_database,
  verifyToken,
} from "../core/utils.mjs";

const member = async (req, res, next) => {
  const userId = req.params.id;
  try {
    let { user_res, cookieUser } = await checkUserAthu(req, res);
    if (!user_res || !cookieUser) return;

    let member_res = await (
      await set_data_in_database(
        `SELECT COUNT(*) as count FROM members WHERE id=?`,
        [userId]
      )
    )[0];
    let path = !user_res ? "pages/login.html" : "pages/member.html";
    if (member_res.count === 0 && user_res)
      path = "pages/not-found-member.html";
    let data = fs.readFileSync(path, "utf8");
    data = data.replace(/\?\=\d+\"/g, "?=" + Math.random() + '"');
    res.send(data);
  } catch (err) {
    errorHand(err);

    next();
    res.status(500).send("Server Error");
  }
};
export default member;
