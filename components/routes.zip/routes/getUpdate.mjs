import { checkUserAthu, errorHand } from "../core/utils.mjs";

const getUpdate = async (req, res, next) => {
  try {
    let { user_res, cookieUser } = await checkUserAthu(req, res);
    if (!user_res || !cookieUser) return;

    if (user_res) {
      let result = await getBackUp();
      if (typeof result === "boolean")
        res.send(
          "<div style='text-aligh:center;padding:10px;background:green;color:white'>success</div>"
        );
      else
        res.send(
          "<div style='text-aligh:center;padding:10px;background:red;color:white'>faild " +
            result +
            " days</div>"
        );
    } else {
      let path = "pages/login.html";
      let data = fs.readFileSync(path, "utf8");
      data = data.replace(/\?\=\d+\"/g, "?=" + Math.random() + '"');
      res.send(data);
    }
  } catch (err) {
    errorHand(err);

    next();
    res.status(500).send("Server Error");
  }
};
export default getUpdate;
